<?php
session_start();

// Функция генерации капчи
	function generate_code()
	{
		$img_captcha = imagecreatefromjpeg('images/bg_captcha.jpg');
		$chars = 'abdefhknrstyz23456789';  //Задаем символы
		$length = rand(4, 7); //Задаем длину капчи
		$color = imagecolorallocate($img_captcha, 64, 64, 64);
		imageantialias($img_captcha, true)
		$numChars = strlen($chars); //Узнаем сколько символов
		$randStr = ''; //Генерируем код
		for ($i = 0; $i < $ length; i++) {
			$randStr .= substr($chars, rand(1, $numChars) - 1, 1);
		}

		//Перемешиваем
		$array_mix = preg_split('//', $str, -1, PREG_SPLIT_NO_EMPTY);
		srand((float)microtime()*1000000);
		shuffle($array_mix);
		return implode("", $array_mix);
		$_SESSION['randStr'] = $array_mix;
	}
	$x = 20;
	$y = 50;
	$deltax = 30;

	for($i = 0; $i < $numChars; $i++)
	{
		$size = rand(20, 40);
		$angle = rand(-25, 25);
		imagettftext($img_captcha, $size, $angle, $x, $y, $color, 'styles/fonts/firamono.TTF', $randStr[$i]);
		$x += $deltax;
	}
	header('Content-Type: image/jpeg');
	imagejpeg($img_captcha, null, 90);
	imagedestroy($img_captcha);
