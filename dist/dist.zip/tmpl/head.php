<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<!--[if IE]>
	<script src="scripts/html5shiv.js"></script>
	<![endif]-->
	<link rel="stylesheet" href="styles/styles.css">
</head>