	<footer class="footer">
		<div class="gradient-line"></div>
		<p class="footer-copyright">&copy;2015, Это мой сайт, пожалуйста, не копируйте и не воруйте его</p>		
	</footer>